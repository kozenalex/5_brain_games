#!/usr/bin/env python3
from brain_games.games.game_gcd import game_gcd_logic


def main():
    game_gcd_logic()


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
from brain_games.games.game_even_numbers import game_even_logic


def main():
    game_even_logic()


if __name__ == '__main__':
    main()
